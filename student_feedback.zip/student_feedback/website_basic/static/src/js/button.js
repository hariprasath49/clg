$(document).ready(function(){
$("form").submit(function(){
    	alert("Your Request is Submitted and you will be acknowledge with mail Thank you, Please click Ok");
  		});
		});
