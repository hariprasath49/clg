from odoo import http, tools, _
from odoo.http import request
import logging
_logger = logging.getLogger(__name__)


class WebsiteBasicForm(http.Controller):
#     partner_name = request.env['res.partner'].sudo().search([])

    @http.route('/test_page/', type='http',auth="public", website=True)
    def website_basic_form(self, **post):
        print post
        lead = None
        
        print request.session.uid 
        usr_name = request.env['res.users'].search([('id', '=',request.session.uid )])
        print usr_name.name,post.get('request')
        
        if post.get('request')==None:
            print post.get('request')
        else:
            lead = request.env['student.detail'].create({
            'name':usr_name.name,
            'request':post.get('request'),
            })
        print lead
#         lead[country_id]=countries 
        print post.get('name')
#         return request.redirect('/test_page2/',lead)
        return request.render("website_basic.basic_template")
    
    
    
     
    @http.route('/test_page2/', type='http',auth="public", website=True)
    def website_basic_form2(self, **post):
        print post
        return request.render("website_basic.basic_template2")
    
    
    
    
    
    